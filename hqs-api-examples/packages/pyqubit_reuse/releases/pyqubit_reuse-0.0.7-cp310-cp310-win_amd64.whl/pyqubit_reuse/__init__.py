# check pytket is installed
try:
    import pytket

    # Importing these two modules so the runtime
    # knows how to bind them
    from pytket import Circuit
    from pytket.passes import BasePass
except ImportError:
    print("pytket is not installed")

from pyqubit_reuse._qubit_reuse.pyqubit_reuse import *
from pyqubit_reuse.ordering_methods import OrderingMethod
