from typing import List, Dict, Tuple, Set
import pandas as pd  # type: ignore
from ortools.linear_solver import pywraplp  # type: ignore
from ortools.sat.python import cp_model  # type: ignore


class MCMRCompilerModel:
    """
    Given a quantum circuit specified by each qubit's ancestors,
    perform exact quantum circuit optimization, returns an
    ordered list for iterating through outputs in a qubit reuse
    algorithm.
    """

    def __init__(
        self,
        qubit_subsets: Dict[int, List[int]],
        hint=None,
    ):

        # Set model inputs
        self.num_qubits: int = len(qubit_subsets.keys())
        self.max_time: int = self.num_qubits
        self.qubit_subsets: Dict[int, List[int]] = qubit_subsets

        # Initialize variable attributes (for readability)
        # These get set during model initialization
        self.x_var: Dict[Tuple[int, int], bool] = {}  # qubit measured
        self.k_var: Dict[Tuple[int, int], bool] = {}  # qubit in queue
        self.max_queue_var = None

        # Initialize solution hint if provided
        self.hint = hint
        self.model = cp_model.CpModel()

        self.set_up_model_variables()
        self.set_up_model_constraints()
        self.model.Minimize(self.max_queue_var)  # sets up objective function
        self.add_hints_after_converting_to_model_vars()

    def set_up_model_variables(self) -> None:
        """Set up model variables"""
        # Indicator if qubit q measured at time t or not, x_qt
        # Indicator if qubit q added to the queue at time t or not, a_qt
        # Indicator if qubit q kept in queue at time t or not, k_qt
        for qubit in range(self.num_qubits):
            for time in range(self.max_time):
                self.x_var[qubit, time] = self.model.NewBoolVar(f"x[{qubit, time}]")
                self.k_var[qubit, time] = self.model.NewBoolVar(f"k[{qubit, time}]")

        # Track max queue size
        self.max_queue_var = self.model.NewIntVar(
            0, self.num_qubits, name="max_queue_length"
        )

    def set_up_model_constraints(self) -> None:
        """Set up model constraints"""
        # Run version utilizing implication constraints
        self.set_up_minimax_constraints()
        self.set_up_add_qubit_to_queue_constraints()
        self.set_up_keep_qubit_in_queue_constraints()
        self.set_up_remove_qubit_from_queue_constraints()
        self.set_up_qubit_meas_once_constraints()
        self.set_up_qubit_unique_meas_constraints()

    def set_up_minimax_constraints(self) -> None:
        """Max Queue length constraint"""
        for time in range(self.max_time):
            # All qubit indicators at time step
            all_t_qubits_k = [t for t in self.k_var if (t[1] == time)]

            (
                self.model.Add(
                    self.max_queue_var
                    >= cp_model.LinearExpr.Sum(
                        [self.k_var[t_qubits] for t_qubits in all_t_qubits_k]
                    )
                )
            )

    def set_up_add_qubit_to_queue_constraints(self) -> None:
        """Enforce qubit's being added to the queue when they are in a
        qubit's job list
        """
        for meas_qubit in range(self.num_qubits):

            # A qubit is added to the queue if a qubit is in a measured qubit's
            # job list.
            job_list = self.qubit_subsets[meas_qubit]

            for job_qubit in job_list:
                for time in range(self.max_time):

                    # When a qubit is added to the queue, it is either added
                    # that time step or was already added/used in a previous
                    # time step
                    all_prev_times = [
                        times
                        for times in self.k_var
                        if ((times[0] == job_qubit) and (times[1] <= time))
                    ]

                    (
                        self.model.Add(
                            cp_model.LinearExpr.Sum(
                                [self.k_var[qtime] for qtime in all_prev_times]
                            )
                            >= 1
                        ).OnlyEnforceIf(self.x_var[meas_qubit, time])
                    )

    def set_up_keep_qubit_in_queue_constraints(self) -> None:
        """Keep a qubit in the queue if it was in the queue last time step,
        but was not measured.
        """
        for qubit in range(self.num_qubits):
            for time in range(1, self.max_time):

                # If a qubit was in the queue last time step,
                # it was either added + measured last time step
                # or was in the queue last time step
                (
                    self.model.Add(
                        self.x_var[qubit, time - 1] + self.k_var[qubit, time] == 1
                    ).OnlyEnforceIf(self.k_var[qubit, time - 1])
                )

                # If a qubit is measured this time step,
                # it is in the queue this time step
                (
                    self.model.Add(self.k_var[qubit, time] == 1).OnlyEnforceIf(
                        self.x_var[qubit, time]
                    )
                )

    def set_up_remove_qubit_from_queue_constraints(self) -> None:
        """Once a qubit is measured, it is never in the queue again."""
        for time in range(self.max_time):
            for qubit in range(self.num_qubits):

                all_later_times_k = [
                    times
                    for times in self.k_var
                    if ((times[0] == qubit) and (times[1] > time))
                ]

                (
                    self.model.Add(
                        cp_model.LinearExpr.Sum(
                            [self.k_var[later_time] for later_time in all_later_times_k]
                        )
                        == 0
                    ).OnlyEnforceIf(self.x_var[qubit, time])
                )

    def set_up_qubit_meas_once_constraints(self) -> None:
        """All qubits must be measured once and only once"""
        for qubit in range(self.num_qubits):
            all_q_times = [qtimes for qtimes in self.x_var if (qtimes[0] == qubit)]

            if all_q_times:
                self.model.Add(
                    cp_model.LinearExpr.Sum(
                        [self.x_var[qtime] for qtime in all_q_times]
                    )
                    == 1
                )

    def set_up_qubit_unique_meas_constraints(self) -> None:
        """All qubits must be measured at different time steps."""
        for time in range(self.max_time):
            all_qubits = [qtimes for qtimes in self.x_var if (qtimes[1] == time)]

            if all_qubits:
                self.model.Add(
                    cp_model.LinearExpr.Sum([self.x_var[qtime] for qtime in all_qubits])
                    == 1
                )

    def add_hints_after_converting_to_model_vars(self) -> None:
        """Converts the solution hint, provided as a permutation of qubits,
        into the x,k variables and adds the appropriate hints.
        """
        if not self.hint:
            return

        added_inputs: Set[int] = set()
        added_outputs: Set[int] = set()

        for time in range(self.max_time):
            current_qubit = self.hint[time]
            current_input_set = self.qubit_subsets[current_qubit]

            # First, add the x_var hints that say which qubit is selected at this time
            self.model.AddHint(self.x_var[current_qubit, time], 1)
            for qubit in range(self.num_qubits):

                if qubit != current_qubit:
                    self.model.AddHint(self.x_var[qubit, time], 0)

                # Now keep track of which qubits are in the queue
                if qubit in added_inputs and qubit not in added_outputs:
                    self.model.AddHint(self.k_var[qubit, time], 1)
                else:
                    self.model.AddHint(self.k_var[qubit, time], 0)

            added_inputs = added_inputs.union(current_input_set)
            added_outputs.add(current_qubit)

    def run_mcc_model(self, time_limit: int = 60, num_threads: int = 1) -> List[int]:

        """Run constraint programming solver

        SearchForAllSolutions Returns:
        The status of the solve:
        * *FEASIBLE: 2* if some solutions have been found
        * *INFEASIBLE: 3* if the solver has proved there are no solution
        * *OPTIMAL: 4* if all solutions have been found

        """
        # Solve Model
        # CP model does not have: EnableOutput, SetNumThreads, VerifySolution
        solver = cp_model.CpSolver()
        solver.parameters.num_search_workers = num_threads
        solver.parameters.max_time_in_seconds = time_limit * 60

        # Save variable values in dataframes if a solution exists
        if solver.Solve(self.model) not in [cp_model.OPTIMAL, cp_model.FEASIBLE]:
            raise ValueError("MCC Model could not find valid solution.")

        xvals = pd.DataFrame.from_dict(self.x_var, orient="index", columns=["x"])
        xvals.reset_index(inplace=True)
        xvals["qubit"] = xvals["index"].apply(lambda val: val[0])
        xvals["time"] = xvals["index"].apply(lambda val: val[1])

        xvals["val"] = xvals["x"].apply(lambda row: solver.Value(row))
        xvals["x"] = xvals.apply(
            lambda row: row["x"].Name()
            if not isinstance(row["x"], int)
            else "x" + "[" + str(row.qubit) + "," + str(row.time) + "]",
            axis=1,
        )

        xvals.drop(["index"], axis=1, inplace=True)
        xvals = xvals.sort_values(by=["qubit", "time"]).reset_index(drop=True)
        nonzero_vals = xvals[xvals["val"] == 1]
        time_ordered_nonzero_vals = nonzero_vals.sort_values(by=["time"])
        return time_ordered_nonzero_vals["qubit"].tolist()
