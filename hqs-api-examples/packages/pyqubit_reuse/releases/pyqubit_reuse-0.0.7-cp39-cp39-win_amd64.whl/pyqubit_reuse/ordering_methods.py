from enum import Enum
from typing import List, Dict, Set
from itertools import permutations
from .mcmr_model import MCMRCompilerModel



class OrderingMethod(Enum):
    """
    Considering a Quantum Circuit as a Directed Acylic Graph (DAG), each Qubits set of operations
    is defined by a single out-edge Input vertex a sequence of linear vertices defining Quantum
    operations connected by edges, and a single in-edge Output vertex. The Qubit can be
    considered as the wire formed from these edges.

    Backtracking from a Qubit Output vertex, we can construct a causal cone of vertices which a
    Qubit wire interacts with. Any multi-qubit vertices will have in and out edges associated
    with other Qubit wires, with these Qubits being "ancestor" Qubits of the Output vertex considered.

    Consider two Qubits A and B. If B is not an ancestor of A, then it implies
    its first (and all its other) quantum operations can be run after the final quantum operation
    of A without effecting the full logical computation done. In practical terms, if one is
    mapping a DAG to physical operations on physical Qubits, then a physical Qubit can
    run all the operations of A, have its state reset to |0>, and then run all the
    operations of B without effecting the logical circuit run. This is the qubit reuse process.

    For a DAG Quantum Circuit condensing the number of Qubit wires by
    combining paths where possible can be done systematically: iterate
    through output vertices, find a qubit wire not in its causal cone,
    add it to the path, find a qubit wire not in the (updated) causal cone, combine.
    The order in which wire care combined can effect the number of Qubit combined and so the
    width of the resulting Circuit.

    This Enum class holds "OrderingMethod", functions that
    given the ancestors for different qubit wire, returns an order to iterate through the output
    vertices so as to minimise the width of the found Circuit.
    """

    def BruteForceOrder():  # type: ignore
        """
        Returns a function for ordering ancestors during qubit reuse.
        """

        def ordering_function(ancestors: Dict[int, List[int]]) -> List[int]:
            """
            Works out all orderings, estimates the number of Qubits there would
            be in the produced Circuit if the ordering was respected, returns
            an ordering corresponding to the smallest width.

            :param ancestors: The indices in ancestors correspond to Qubits in
            some Quantum Circuit. For each Key, Value pair in ancestors, the List[int]
            value gives all other (indexed) Qubits in the Circuit that have a multi-qubit
            gates in the causal cone of the Key Qubit.
            :type ancestors: Dict[int, List[int]]

            :return: Ordered list for iterating through outputs
            """

            def comparison(permutation: List[int]) -> int:
                """
                For each permutation, estimate the number of Qubits in the produced
                Circuit if reordering iterated through output vertices in the
                ordered given by "permutation"

                :param permutation: Candidate order for iterating through output vertices
                when completing qubit reuse.
                :type permutation: List[int]

                :return: Estimate number of Qubits in reordered Circuit if using ordering
                provided by "permutation"
                :rtype: int
                """
                checked_ancestors: List[bool] = [False] * len(permutation)
                max_queue_size: int = 0
                potential_queue_size: int = 0

                for output in permutation:
                    # n.b. ancestors as is passed to BruteForceOrder
                    for qubit in ancestors[output]:
                        # condition is if two paths are merged, meaning number of
                        # qubits in output is larger
                        # if qubit not in checked_ancestors:
                        if not checked_ancestors[qubit]:
                            potential_queue_size += 1
                            checked_ancestors[qubit] = True
                    # value generally increases as we try more outputs from permutation
                    # but value is variable and can decrease
                    max_queue_size = max(potential_queue_size, max_queue_size)

                    # implies that this output has already been wired to
                    # the back of another wire i.e. has already contributed to estimate
                    # if output in checked_ancestors:
                    if checked_ancestors[output]:
                        potential_queue_size -= 1
                        assert potential_queue_size >= 0
                    #  if its not, add it
                    else:
                        checked_ancestors[output] = True

                return max_queue_size

            return list(min(permutations(ancestors), key=comparison))  # type : ignore

        return ordering_function

    def ConstrainedOptOrder(  # type: ignore
        time_limit: int = 600,
        n_threads: int = 1,
        hint: List[int] = None,  # type: ignore
    ):
        """
        Returns a function for ordering ancestors during qubit reuse.

        :param save_directory: Directory to send results to.
        :type save_directory: str
        :param time_limit: Maximum time spent finding order
        :type time_limit: int
        :param n_threads: Number of threads opened for finding solutions
        :type n_threads: int
        :param quiet_flag: Suppress prints
        :type quiet_flag:
        :param hint: List of integers giving suggested ordering known to be effective.
        :type hint: List[int]
        """

        def ordering_function(ancestors: Dict[int, List[int]]) -> List[int]:
            """
            :param ancestors: The indices in ancestors correspond to Qubits
            in some Quantum Circuit. For each Key, Value pair in ancestors,
            the List[int] value gives all other (indexed) Qubits in the Circuit
            that have a multi-qubit gates in the causal cone of the Key Qubit.
            :type ancestors: Dict[int, List[int]]

            :return: Ordered list for iterating through outputs
            """
            return MCMRCompilerModel(ancestors, hint=hint).run_mcc_model(
                time_limit=time_limit, num_threads=n_threads
            )

        return ordering_function

    def LocalGreedyOrder():  # type: ignore
        """
        Returns a function for ordering ancestors during qubit reuse.
        """

        def ordering_function(ancestors: Dict[int, List[int]]) -> List[int]:
            """
            :param ancestors: The indices in ancestors correspond to Qubits
             in some Quantum Circuit. For each Key, Value pair in
             ancestors, the List[int] value gives all other (indexed)
             Qubits in the Circuit that have a multi-qubit gates in the
             causal cone of the Key Qubit.
            :type ancestors: Dict[int, List[int]]

            :return: Ordered list for iterating through outputs
            """
            output_order: List[int] = list()
            added_inputs: Set[int] = set()
            remaining_outputs: Set[int] = set(ancestors.keys())

            while remaining_outputs:
                min_output = min(
                    remaining_outputs,
                    key=lambda output: len(set(ancestors[output]) - added_inputs),
                )
                added_inputs.update(ancestors[min_output])
                remaining_outputs.remove(min_output)
                output_order.append(min_output)

            return output_order

        return ordering_function

    def LocalGreedyFirstNodeSearchOrder():  # type: ignore
        """
        Returns a function for ordering ancestors during qubit reuse.
        """

        def ordering_function(ancestors: Dict[int, List[int]]) -> List[int]:
            """
            :param ancestors: The indices in ancestors correspond to Qubits
            in some Quantum Circuit. For each Key, Value pair in ancestors,
            the List[int] value gives all other (indexed) Qubits in the
            Circuit that have a multi-qubit gates in the causal cone of the Key Qubit.
            :type ancestors: Dict[int, List[int]]

            :return: Ordered list for iterating through outputs
            """
            orders_bin: Dict[int, List[int]] = dict()

            def comparison(output: int) -> int:
                output_order: List[int] = [output]
                remaining_outputs: Set[int] = set(ancestors.keys())
                remaining_outputs.remove(output)
                added_inputs: Set[int] = set(ancestors[output])
                max_queue_length: int = len(added_inputs)

                while remaining_outputs:
                    min_output = min(
                        remaining_outputs,
                        key=lambda x: len(set(ancestors[x]) - added_inputs),
                    )
                    added_inputs.update(ancestors[min_output])
                    max_queue_length = max(
                        max_queue_length, len(added_inputs) - len(output_order)
                    )
                    remaining_outputs.remove(min_output)
                    output_order.append(min_output)

                orders_bin[output] = output_order
                return max_queue_length

            return orders_bin[min(ancestors, key=comparison)]

        return ordering_function

    def CustomOrder(order: List[int]):  # type: ignore
        """
        Always returns the order specified by "order".
        If the int in "order" do not exactly match the int
        passed to the internal ordering fucntion then an
        assertion is hit.

        :param order: Order of integers to iterate through when merging causal cones.
        :type order: List[int]
        """

        def ordering_function(ancestors: Dict[int, List[int]]) -> List[int]:
            """
            :param ancestors: The indices in ancestors correspond to Qubits in some Quantum Circuit.
             For each Key, Value pair in ancestors, the List[int] value gives all other (indexed)
             Qubits in the Circuit that have a multi-qubit gates in the causal cone of the Key Qubit.
            :type ancestors: Dict[int, List[int]]

            :return: Ordered list for iterating through outputs
            """
            if set(order) != set(ancestors.keys()):
                raise ValueError(
                    "The indices in the passed order to CustomOrder do not match the "
                    "indices of the causal cones passed to the ordering function."
                )
            return order

        return ordering_function

    def DefaultOrder():  # type: ignore
        """
        Switches the Ordering Method used depending on the number of Qubits in the Circuit.
        """

        def ordering_function(ancestors: Dict[int, List[int]]) -> List[int]:
            """
            :param ancestors: The indices in ancestors correspond to Qubits in some Quantum Circuit.
             For each Key, Value pair in ancestors, the List[int] value gives all other (indexed)
             Qubits in the Circuit that have a multi-qubit gates in the causal cone of the Key Qubit.
            :type ancestors: Dict[int, List[int]]

            :return: Ordered list for iterating through outputs
            """
            n_outputs: int = len(ancestors)
            if n_outputs <= 9:
                return OrderingMethod.BruteForceOrder()(ancestors)
            if n_outputs <= 30:
                return OrderingMethod.ConstrainedOptOrder()(ancestors)
            if n_outputs <= 1000:
                return OrderingMethod.LocalGreedyFirstNodeSearchOrder()(ancestors)
            return OrderingMethod.LocalGreedyOrder()(ancestors)

        return ordering_function
